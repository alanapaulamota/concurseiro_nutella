from app.models.usuario_model import Base, engine
import app.models.usuario_model  
import app.models.concurso_model  

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("Tabelas criadas com sucesso.")
