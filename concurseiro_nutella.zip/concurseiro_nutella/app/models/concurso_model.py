from sqlalchemy import Column, Integer, String, Date
from app.config.database import Base

class Concurso(Base):
    __tablename__ = "concursos"

    id = Column(Integer, primary_key=True, index=True)
    orgao = Column(String(100))
    cargo = Column(String(100))
    nivel = Column(String(50))
    salario = Column(String(20))
    vagas = Column(Integer)
    data_prova = Column(Date)
