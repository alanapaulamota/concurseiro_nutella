from sqlalchemy import Column, Integer, String, Table
from app.config.database import Base

class Usuario(Base):
    __tablename__ = "usuarios"
    __table_args__ = {'extend_existing': True}  # ← esta linha resolve o problema

    id = Column(Integer, primary_key=True, index=True)
    nome = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    senha = Column(String(255), nullable=False)
