from pydantic import BaseModel
from typing import Optional
from datetime import date

class ConcursoBase(BaseModel):
    orgao: str
    cargo: str
    nivel: Optional[str] = None
    salario: Optional[str] = None
    vagas: Optional[int] = None
    data_prova: Optional[date] = None

class ConcursoCreate(ConcursoBase):
    pass

class ConcursoUpdate(BaseModel):
    orgao: Optional[str] = None
    cargo: Optional[str] = None
    nivel: Optional[str] = None
    salario: Optional[str] = None
    vagas: Optional[int] = None
    data_prova: Optional[date] = None

class ConcursoOut(ConcursoBase):
    id: int

    class Config:
        from_attributes = True
