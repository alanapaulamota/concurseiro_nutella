from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
import os

from app.config.database import Base, engine
from app.config.init_db import init_db  

# Routers
from app.routers import (
    auth_router,
    dashboard,
    edna_router,
    usuario_router,
    concurso_router,
    rag_router
)

app = FastAPI()

# Middleware de sessão
app.add_middleware(SessionMiddleware, secret_key="sua_chave_secreta")

# Diretório base do projeto
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Configuração de templates e arquivos estáticos
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

# Páginas HTML
@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/forgot-password", response_class=HTMLResponse)
async def forgot_password_page(request: Request):
    return templates.TemplateResponse("forgot-password.html", {"request": request})

# ✅ Rota para checar status da API
@app.get("/status")
async def status():
    return JSONResponse(content={"status": "ok", "message": "API rodando com sucesso 🚀"})

# Rotas da aplicação
app.include_router(auth_router.router)
app.include_router(dashboard.router)
app.include_router(edna_router.router)
app.include_router(usuario_router.router)
app.include_router(concurso_router.router)
app.include_router(rag_router.router, prefix="/api", tags=["RAG"])

# Inicializa o banco ao rodar diretamente (opcional, se não usar Alembic)
if __name__ == "__main__":
    init_db()
    print("*****************************************************************************")
    print("✅ Sistema iniciado com sucesso!")
