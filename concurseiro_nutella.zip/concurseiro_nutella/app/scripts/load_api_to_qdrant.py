# app/scripts/load_api_to_qdrant.py

import requests
from langchain.embeddings import OllamaEmbeddings
from langchain.vectorstores import Qdrant
from qdrant_client import QdrantClient
from qdrant_client.http.models import VectorParams, Distance
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document

# ⚙️ Configs
API_URL = "https://api.exemplo.gov.br/textos/concurso"  # ← troque para a API real
COLLECTION_NAME = "concurseiro_docs"

# 🚀 Pega os dados da API
def extrair_texto_da_api():
    response = requests.get(API_URL)
    data = response.json()

    # Extração personalizada do conteúdo textual
    textos = [item["conteudo"] for item in data if "conteudo" in item]
    return textos

# 🔧 Prepara o Qdrant
def configurar_qdrant():
    client = QdrantClient(host="localhost", port=6333)

    if not client.collection_exists(COLLECTION_NAME):
        client.recreate_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=VectorParams(size=4096, distance=Distance.COSINE)
        )
    return client

# 🧠 Processa e envia pro Qdrant
def indexar_conteudo():
    textos = extrair_texto_da_api()
    qdrant = configurar_qdrant()
    embeddings = OllamaEmbeddings(model="nomic-embed-text")

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    documentos = []

    for texto in textos:
        partes = text_splitter.split_text(texto)
        documentos.extend([Document(page_content=parte) for parte in partes])

    Qdrant.from_documents(
        documents=documentos,
        embedding=embeddings,
        qdrant_client=qdrant,
        collection_name=COLLECTION_NAME
    )

    print(f"{len(documentos)} chunks indexados com sucesso no Qdrant.")

if __name__ == "__main__":
    indexar_conteudo()
