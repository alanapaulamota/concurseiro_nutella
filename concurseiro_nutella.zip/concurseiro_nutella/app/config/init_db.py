# app/config/init_db.py
from app.config.database import Base, engine
from app.models import usuario_model  # importe todos os models que criar tabelas

def init_db():
    Base.metadata.create_all(bind=engine)
