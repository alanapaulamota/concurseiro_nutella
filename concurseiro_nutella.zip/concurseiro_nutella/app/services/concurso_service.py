from sqlalchemy.orm import Session
from app.models.concurso_model import Concurso
from app.schemas.concurso_schema import ConcursoCreate, ConcursoUpdate

def criar_concurso(db: Session, concurso: ConcursoCreate):
    novo = Concurso(**concurso.dict())
    db.add(novo)
    db.commit()
    db.refresh(novo)
    return novo

def listar_concursos(db: Session):
    return db.query(Concurso).all()

def obter_concurso_por_id(db: Session, concurso_id: int):
    return db.query(Concurso).filter(Concurso.id == concurso_id).first()

def atualizar_concurso(db: Session, concurso_id: int, dados: ConcursoUpdate):
    concurso = obter_concurso_por_id(db, concurso_id)
    if not concurso:
        return None
    for key, value in dados.dict(exclude_unset=True).items():
        setattr(concurso, key, value)
    db.commit()
    db.refresh(concurso)
    return concurso

def deletar_concurso(db: Session, concurso_id: int):
    concurso = obter_concurso_por_id(db, concurso_id)
    if not concurso:
        return None
    db.delete(concurso)
    db.commit()
    return concurso
