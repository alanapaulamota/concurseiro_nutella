from langchain_community.vectorstores import Qdrant
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama.embeddings import OllamaEmbeddings
from langchain_ollama.llms import OllamaLLM
from langchain.chains import RetrievalQA
from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance
import os

# Caminho para os documentos
DOCUMENTS_DIR = "app/data/docs"
collection_name = "concurseiro_nutella"

# Carregar os documentos (todos os .txt da pasta)
docs = []
for filename in os.listdir(DOCUMENTS_DIR):
    if filename.endswith(".txt"):
        filepath = os.path.join(DOCUMENTS_DIR, filename)
        loader = TextLoader(filepath)
        docs.extend(loader.load())

# Dividir os documentos em chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
documents = text_splitter.split_documents(docs)

# Inicializar embeddings com modelo do Ollama
embeddings = OllamaEmbeddings(model="nomic-embed-text")

# Inicializar Qdrant local
qdrant = QdrantClient(
    path="app/data/qdrant_db"
)

# Criar a coleção se não existir
if not qdrant.collection_exists(collection_name):
    qdrant.recreate_collection(
        collection_name=collection_name,
        vectors_config=VectorParams(size=768, distance=Distance.COSINE),
    )

# Criar vectorstore
vectorstore = Qdrant(
    client=qdrant,
    collection_name=collection_name,
    embeddings=embeddings
)

# Adicionar documentos ao vectorstore
vectorstore.add_documents(documents)

# Inicializar LLM
llm = OllamaLLM(model="llama3")

# Criar chain de QA com recuperação
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=vectorstore.as_retriever()
)

# Função para responder pergunta
def responder_pergunta(pergunta: str) -> str:
    resposta = qa_chain.invoke(pergunta)
    return resposta

def responder_com_edna(pergunta: str) -> str:
    resposta = responder_pergunta(pergunta)
    return resposta["result"]  # ou apenas return resposta se já for string
