# app/services/auth_service.py

from passlib.context import CryptContext
from app.models.usuario_model import Usuario
from app.config.database import SessionLocal
from sqlalchemy.exc import IntegrityError

from fastapi import Depends, Request, HTTPException
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Simulação de "decodificação" do token
async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    if not token:
        raise HTTPException(status_code=401, detail="Token não fornecido.")
    # Aqui você normalmente validaria o token e buscaria o usuário no banco
    # Exemplo fixo:
    return {"id": 1, "email": "teste@exemplo.com"}


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Criptografa senha
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

# Verifica se a senha está correta
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

# Autentica usuário
def authenticate_user(email: str, senha: str) -> dict | None:
    db = SessionLocal()
    try:
        usuario = db.query(Usuario).filter(Usuario.email == email).first()
        if not usuario or not verify_password(senha, usuario.senha):
            return None
        return {"id": usuario.id, "email": usuario.email}
    finally:
        db.close()

# Salva novo usuário
def salvar_usuario(nome: str, email: str, senha: str) -> Usuario:
    db = SessionLocal()
    try:
        if db.query(Usuario).filter(Usuario.email == email).first():
            raise Exception("E-mail já cadastrado.")
        
        senha_criptografada = hash_password(senha)
        novo_usuario = Usuario(nome=nome, email=email, senha=senha_criptografada)
        db.add(novo_usuario)
        db.commit()
        db.refresh(novo_usuario)
        return novo_usuario
    except IntegrityError:
        db.rollback()
        raise Exception("Erro ao salvar usuário.")
    finally:
        db.close()
