import requests
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue, SearchRequest
import os

# Conectando ao Qdrant
qdrant = QdrantClient(host="localhost", port=6333)
COLLECTION_NAME = "base_edna"

# Conectando ao Ollama
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3"  # pode trocar por "phi3" ou outro modelo baixado

def buscar_contexto(mensagem: str, k: int = 3) -> str:
    try:
        results = qdrant.search(
            collection_name=COLLECTION_NAME,
            query_vector=gerar_embedding(mensagem),
            limit=k
        )
        textos = [result.payload.get("texto", "") for result in results]
        return "\n".join(textos)
    except Exception as e:
        return "Não consegui buscar contexto. Edna tá meio perdida hoje."

def gerar_embedding(texto: str):
    # Pode trocar por seu próprio método de embedding, aqui é só um exemplo fake
    import hashlib
    return [float(int(hashlib.sha1((texto + str(i)).encode()).hexdigest(), 16) % 1000) for i in range(1536)]

def gerar_resposta_ollama(pergunta: str, contexto: str) -> str:
    prompt = f"""
Você é a Edna, uma assistente inteligente e simpática para concurseiros.

Baseado no contexto abaixo, responda à pergunta do usuário de forma clara e objetiva.

Contexto:
{contexto}

Pergunta:
{pergunta}
    """
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False
    }

    response = requests.post(OLLAMA_URL, json=payload)
    if response.status_code == 200:
        return response.json()["response"]
    else:
        return "Não consegui gerar resposta com o modelo no momento 😢"

def responder_edna(mensagem: str) -> str:
    contexto = buscar_contexto(mensagem)
    resposta = gerar_resposta_ollama(mensagem, contexto)
    return f"👩‍💼 Edna: {resposta.strip()}"
