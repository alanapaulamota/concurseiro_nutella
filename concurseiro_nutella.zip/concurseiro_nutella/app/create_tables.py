# app/create_tables.py

from app.config.database import Base, engine  # ← IMPORTA corretamente
import app.models.usuario_model
import app.models.concurso_model

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("Tabelas criadas com sucesso.")
