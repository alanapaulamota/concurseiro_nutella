from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from starlette.status import HTTP_302_FOUND
from pathlib import Path

from app.services.auth_service import authenticate_user, hash_password
from app.models.usuario_model import Usuario
from app.config.database import SessionLocal

router = APIRouter()

# Diretório de templates
BASE_DIR = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = BASE_DIR / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

# ------------------- ROTAS ---------------------

# ROTA: Página de Login (GET)
@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


# ROTA: Autenticação de Login (POST)
@router.post("/login")
async def login_post(request: Request, email: str = Form(...), password: str = Form(...)):
    user = authenticate_user(email, password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "E-mail ou senha incorretos."
        })
    request.session["user"] = user["email"]
    return RedirectResponse(url="/dashboard", status_code=HTTP_302_FOUND)


# ROTA: Logout
@router.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/login", status_code=HTTP_302_FOUND)


# ROTA: Dashboard (após login)
@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    if not request.session.get("user"):
        return RedirectResponse(url="/login", status_code=HTTP_302_FOUND)
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": request.session["user"]
    })


# ROTA: Página de Registro (GET)
@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


# ROTA: Registro de Novo Usuário (POST)
@router.post("/register")
async def register_user(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...)
):
    db = SessionLocal()

    # Validação de senha
    if password != confirm_password:
        return templates.TemplateResponse("register.html", {
            "request": request,
            "erro": "As senhas não coincidem."
        })

    # Verifica se o e-mail já está cadastrado
    usuario_existente = db.query(Usuario).filter(Usuario.email == email).first()
    if usuario_existente:
        return templates.TemplateResponse("register.html", {
            "request": request,
            "erro": "E-mail já cadastrado."
        })

    # Criação e salvamento do novo usuário
    senha_hash = hash_password(password)
    novo_usuario = Usuario(nome=name, email=email, senha=senha_hash)
    db.add(novo_usuario)
    db.commit()
    db.close()

    return RedirectResponse(url="/login", status_code=HTTP_302_FOUND)
