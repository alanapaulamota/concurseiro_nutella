from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.schemas.concurso_schema import ConcursoCreate, ConcursoOut, ConcursoUpdate
from app.services import concurso_service
from app.config.database import get_db

router = APIRouter(prefix="/concursos", tags=["Concursos"])

@router.post("/", response_model=ConcursoOut, status_code=status.HTTP_201_CREATED)
def criar(concurso: ConcursoCreate, db: Session = Depends(get_db)):
    return concurso_service.criar_concurso(db, concurso)

@router.get("/", response_model=List[ConcursoOut])
def listar(db: Session = Depends(get_db)):
    return concurso_service.listar_concursos(db)

@router.get("/{concurso_id}", response_model=ConcursoOut)
def buscar(concurso_id: int, db: Session = Depends(get_db)):
    concurso = concurso_service.obter_concurso_por_id(db, concurso_id)
    if not concurso:
        raise HTTPException(status_code=404, detail="Concurso não encontrado")
    return concurso

@router.put("/{concurso_id}", response_model=ConcursoOut)
def atualizar(concurso_id: int, dados: ConcursoUpdate, db: Session = Depends(get_db)):
    concurso = concurso_service.atualizar_concurso(db, concurso_id, dados)
    if not concurso:
        raise HTTPException(status_code=404, detail="Concurso não encontrado")
    return concurso

@router.delete("/{concurso_id}", status_code=status.HTTP_204_NO_CONTENT)
def deletar(concurso_id: int, db: Session = Depends(get_db)):
    concurso = concurso_service.deletar_concurso(db, concurso_id)
    if not concurso:
        raise HTTPException(status_code=404, detail="Concurso não encontrado")
