# app/routers/rag_router.py

from fastapi import APIRouter
from pydantic import BaseModel
from app.services.rag_service import responder_pergunta

router = APIRouter(
    prefix="/rag",
    tags=["RAG"]
)

class PerguntaInput(BaseModel):
    pergunta: str

class RespostaOutput(BaseModel):
    resposta: str

@router.post(
    "/perguntar",
    summary="Enviar pergunta para o RAG",
    description="Recebe uma pergunta do usuário e retorna uma resposta usando RAG.",
    response_model=RespostaOutput
)
async def perguntar_rag(data: PerguntaInput):
    resposta = responder_pergunta(data.pergunta)
    return {"resposta": resposta}
