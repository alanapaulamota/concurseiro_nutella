from fastapi import APIRouter, Request
from pydantic import BaseModel
from app.services.rag_service import responder_com_edna 
from fastapi.templating import Jinja2Templates

templates = Jinja2Templates(directory="templates")


router = APIRouter()

class Pergunta(BaseModel):
    pergunta: str

@router.post("/api/edna/perguntar")
async def perguntar_edna(pergunta: Pergunta):
    try:
        print(">>> Pergunta recebida:", pergunta.pergunta)
        resposta = responder_com_edna(pergunta.pergunta)
        return {"resposta": resposta}
    except Exception as e:
        print(">>> ERRO ao responder:", e)
        return {"erro": str(e)}
