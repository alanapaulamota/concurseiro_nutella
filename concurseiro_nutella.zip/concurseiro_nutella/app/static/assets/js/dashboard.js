document.addEventListener("DOMContentLoaded", function () {
  // Gráfico
  const ctx = document.getElementById("graficoDesempenho").getContext("2d");

  new Chart(ctx, {
    type: "line",
    data: {
      labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"],
      datasets: [{
        label: "Desempenho (%)",
        data: [70, 75, 80, 82, 90, 92],
        borderColor: "#0d6efd",
        backgroundColor: "rgba(13, 110, 253, 0.1)",
        fill: true,
        tension: 0.4,
        pointBackgroundColor: "#0d6efd"
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          max: 100
        }
      }
    }
  });

  // Abrir/fechar modal do chat
  document.getElementById('chatEdnaBtn').addEventListener('click', () => {
    document.getElementById('chatEdnaModal').style.display = 'flex';
  });

  document.getElementById('closeChatEdna')?.addEventListener('click', () => {
    document.getElementById('chatEdnaModal').style.display = 'none';
  });

  // Enviar mensagem
  document.getElementById('chatEdnaSend').addEventListener('click', enviarMsg);
  document.getElementById('chatEdnaInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') enviarMsg();
  });

  function enviarMsg() {
    const input = document.getElementById('chatEdnaInput');
    const mensagem = input.value.trim();
    if (!mensagem) return;

    const chat = document.getElementById('chatEdnaMsgs');

    // Adiciona mensagem do usuário
    const userDiv = document.createElement('div');
    userDiv.className = 'chat-mensagem user';
    userDiv.innerText = mensagem;
    chat.appendChild(userDiv);

    // Limpa input
    input.value = '';

    // Envia pro backend
    fetch("/api/edna/perguntar", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ pergunta: mensagem }),
    })
      .then(response => response.json())
      .then(data => {
        const botDiv = document.createElement('div');
        botDiv.className = 'chat-mensagem bot';
        botDiv.innerHTML = `👩‍💼 <strong>Edna:</strong> ${data.resposta}`;
        chat.appendChild(botDiv);
        chat.scrollTop = chat.scrollHeight;
      })
      .catch(error => {
        console.error("Erro ao se comunicar com a Edna:", error);
        const botDiv = document.createElement('div');
        botDiv.className = 'chat-mensagem bot';
        botDiv.innerText = 'Ops! Não consegui te responder agora 😢';
        chat.appendChild(botDiv);
        chat.scrollTop = chat.scrollHeight;
      });
  }
});
