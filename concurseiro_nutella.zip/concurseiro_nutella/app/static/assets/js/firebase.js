// Importa os módulos do Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-analytics.js";

// Configuração do Firebase (os dados são os que você copiou da sua conta)
const firebaseConfig = {
  apiKey: "AIzaSyAYA-41zw4vi6VqvUFtR56pqTYddidjRXc",
  authDomain: "site-chatbot-concursos.firebaseapp.com",
  projectId: "site-chatbot-concursos",
  storageBucket: "site-chatbot-concursos.firebasestorage.app",
  messagingSenderId: "683838735065",
  appId: "1:683838735065:web:00cee0091b4f21bf0834c8",
  measurementId: "G-95TG6QGFH7"
};

// Inicializa o Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
